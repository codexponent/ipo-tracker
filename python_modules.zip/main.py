import scrapy

url = "https://www.google.com"


name = "quotes"

def start_requests():
    urls = [
        'http://quotes.toscrape.com/page/1/',
        'http://quotes.toscrape.com/page/2/',
    ]
    for url in urls:
        yield scrapy.Request(url=url, callback=self.parse)

url = 'http://quotes.toscrape.com/page/2/'
page = response.url.split("/")[-2]
filename = f'quotes-{page}.html'
with open(filename, 'wb') as f:
    f.write(response.body)
    print(response.body)
log(f'Saved file {filename}')

start_requests()